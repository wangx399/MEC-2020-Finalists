# Installation Guide
- Before running: 
  - Have flask installed
  - Have the python library CountryInfo installed

* To run: Run the python file test.py (python3 test.py)

# Testing
# ["Country Name"], [Total Cases], [New Cases], [Total Deaths], [Total Recovered], [Active Cases]
# Updated testing file to fix comma error, sorry!
