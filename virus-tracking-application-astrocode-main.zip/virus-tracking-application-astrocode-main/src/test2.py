import math
from readData import *
from analyzeData import *

countries = readData("testing.txt")

print(sortTotalCases(countries))